# Videos Directory

Thư mục này chứa các file video để sử dụng với lệnh |\1`.

## Cách sử dụng:

1. **Thêm video thủ công:** Đặt các file video vào thư mục này
2. **Tải video từ URL:** Sử dụng lệnh |\1 add <URL> <tên file>` (chỉ admin)
3. **Gửi video:** Sử dụng lệnh |\1 <tên file>` trong Discord
4. **Xem danh sách:** Sử dụng lệnh |\1` hoặc |\1`

## Định dạng được hỗ trợ:

- `.mp4` (khuyến nghị)
- `.avi`
- `.mov`
- `.mkv`
- `.wmv`
- `.flv`
- `.webm`
- `.m4v`

## Giới hạn:

- Kích thước tối đa: **25MB** (giới hạn của Discord)
- Bot cần quyền "Attach Files" trong kênh để gửi video

## Ví dụ:

```
;video add https://example.com/funny_cat.mp4 funny_cat.mp4
;video funny_cat.mp4
;video meme
;listvideo
```

## Lưu ý:

- Tên file không phân biệt hoa thường
- Có thể bỏ qua phần mở rộng file khi gõ lệnh
- Bot sẽ tự động xóa tin nhắn lệnh sau khi gửi video thành công
- Lệnh |\1 add` chỉ dành cho admin (có quyền warn)
- Giới hạn tải về: **100MB** (lớn hơn giới hạn gửi của Discord)
- Timeout tải về: **5 phút**
